package com.sh.P1;

import java.util.ArrayList;

public class P1 {

	public static void main(String[] args) {
		ArrayList<Integer> array=new ArrayList<Integer>();
		array.add(-113);
		array.add(-113);
		array.add(-113);	
		array.add(-113);
		array.add(-113);
		array.add(11);
		long a=System.currentTimeMillis();
		for(int r:array) {
			System.out.println(r);
		}
		long b=System.currentTimeMillis();
		System.out.println(b-a);
		array.forEach(i -> System.out.println("Slot contains a- "+i));
		long c=System.currentTimeMillis();;
		System.out.println(c-b);

		}
		


}


//Create an ArrayList that can hold Integers. Add ten copies of the number -113 to the ArrayList. Then display the contents of the ArrayList on the scree
//OutPut
//Slot 0 contains a -113
//Slot 1 contains a -113
//Slot 2 contains a -113
//Slot 3 contains a -113
//Slot 4 contains a -11