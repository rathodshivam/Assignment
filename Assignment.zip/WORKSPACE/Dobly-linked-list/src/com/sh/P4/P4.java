package com.sh.P4;

import java.util.Arrays;

import com.sh.LinkedList.LinkedList;
import com.sh.LinkedList.LinkedListInerface;
import com.sh.LinkedList.SynchronizedLinkedList;

class P4{
	public static void main(String[] args) {
		LinkedListInerface list=new LinkedList();
		list.addAtEnd(2);
		list.addAtEnd(3);
		list.addAtEnd(4);	
		list.addAtEnd(5);
		list.AddAtPos(16, 5);
		System.out.println(Arrays.toString(list.getAll()));		
		System.out.println("===========================================");
		LinkedListInerface synList=new SynchronizedLinkedList((LinkedList)list);
		synList.addAtEnd(25);
		System.out.println(Arrays.toString(synList.getAll()));
		System.out.println("===========================================");
		System.out.println(Arrays.toString(list.getAll()));
		System.out.println("===========================================");
		list.deleteFromLast();
		System.out.println(Arrays.toString(list.getAll()));
		System.out.println("the element is at "+list.search(5));
	}
}