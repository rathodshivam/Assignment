package com.sh.node;
//node java bean class
public class node {
	int data;
	node next;
	node prev;
//	constructor
	public node(int data, node next, node prev) {
		this.data = data;
		this.next = next;
		this.prev = prev;
	}
//	constructor
	public node() {
		next=null;
		prev=null;
	}
//getters and setters
	public int getData() {
		return data;
	}
	public void setData(int data) {
		this.data = data;
	}
	public node getNext() {
		return next;
	}
	public void setNext(node next) {
		this.next = next;
	}
	public node getPrev() {
		return prev;
	}
	public void setPrev(node prev) {
		this.prev = prev;
	}
}