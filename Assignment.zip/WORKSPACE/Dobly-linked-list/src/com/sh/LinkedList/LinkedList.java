package com.sh.LinkedList;

import com.sh.node.node;

public class LinkedList implements LinkedListInerface {
	protected node start;
	protected node end;
	int size=0;
//	constructor
	public LinkedList() {
		start=null;
		end=null;
		size=0;
	}
//	get size of the list
	public int getSize() {
		return size;
	}
//	print all elements in List
	public Integer[] getAll() {
		Integer[] temp=new Integer[size];
		if(start==null)
			return null;
		for(int i=0;i<size;i++) {
			temp[i]=getPos(i+1);
		}
		return temp;
	}
//	get element at specific position in list
	public Integer getPos(int pos) {
		if(start==null)
			return null;
		else if(pos<1)
			throw new RuntimeException("The position must be greater 0");			
		else if(pos==1) {
			return getFirst();
		}
		else if(pos==size) {
			return getLast();
			
		}
		else if(pos>size)
			throw new RuntimeException("The position must be less than size");
		node head=start;
		for(int i=2;i<=size;i++) {
			head=head.getNext();
			if(i==pos) {
				return head.getData();
			}
		}
		return null;
	}
//	Print first element
	public Integer getFirst() {
		if(start==null)
			return null;
		else
			return start.getData();
	}
//	get last element
	public Integer getLast() {
		if(start==null)
			return null;
		else
			return end.getData();
	}
//	Add element add start
	public void addAtStart(int data) {
		node e=new node(data,null,null);
		if(start==null) {
			start=e;
			end=start;
		}
		else {
			start.setPrev(e);
			e.setNext(start);
			start=e;
		}
		size++;
	}
//	Add element at last
	public void addAtEnd(int data) {
		node e=new node(data, null, null);
		if(start==null) {
			start=e;
			end=start;
		}
		else {
			end.setNext(e);
			e.setPrev(end);
			end=e;
		}
		size++;
	}
//	Add element at Specific Position
	public void AddAtPos(int data,int pos) {
		if(pos==1) {
			addAtStart(data);
			return;
		}
		else if(pos==size+1) {
			addAtEnd(data);
			return;
		}
		else if(pos>size)
			throw new RuntimeException("not possible");
		node head=start;
		node lastHead;
		for(int i=2;i<=size;i++) {
			lastHead=head;
			head=head.getNext();
			if(i==pos) {
				node e=new node(data, null, null);
				e.setPrev(lastHead);
				lastHead.setNext(e);
				e.setNext(head);
				head.setPrev(e);
			}
				
		}
		size++;
	}
	public void deleteFromStart()
	{
		if(size==1)
		{
			start=null;
		}
			start=start.getNext();
			start.setPrev(null);
			size--;
		
	}
	public void deleteFromLast()
	{
		end=end.getPrev();
		end.setNext(null);
		size--;
	}
	public void deleteFromPosition(int pos)
	{
		node n=new node();
		node head=start;
		node lastHead=head;
		int i=0;
		if (pos==1)
		{
			deleteFromStart();
			return;
		}
		else if(pos==size+1)
		{
			deleteFromLast();
			return;
		}
		else{
			while(i!=pos)
			{
				lastHead=head;
				head=head.getNext();
				i++;
			}
			head=head.getNext();
			lastHead.setNext(head);
			head.setPrev(lastHead);
		}
		size--;
	}
//	sort the element in list
	public void sort() {
		node a=new node();
		node b=new node();
		int i=0,j=0;
		if(start==null) {
			System.out.println("Notthing to sort.");
			return;
		}
		else if(size==2) {
			if(start.getData()>end.getData()) {
				start.setData(start.getData()+end.getData());
				end.setData(start.getData()-end.getData());
				start.setData(start.getData()-end.getData());
			}
		}
		for(a=start,i=0;i<size;i++,a=a.getNext()) 
			for(b=a,j=i;j<size;j++,b=b.getNext()) 	
				if(a.getData()>b.getData()) {
					a.setData(a.getData()+b.getData());
					b.setData(a.getData()-b.getData());
					a.setData(a.getData()-b.getData());
				}		
	}
//	search element in List
	public Integer search(int data) {
		node head=start;
		if(start==null)
			return null;
		else if(start.getNext()==null && start.getData()==data)
			return 1;
		for(int i=1;i<=size;i++) {
			if(head.getData()==data)
				return i;
			head=head.getNext();
		}
		return null;
	}
}
	