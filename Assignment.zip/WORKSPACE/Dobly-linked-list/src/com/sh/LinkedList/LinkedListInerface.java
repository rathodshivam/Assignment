package com.sh.LinkedList;

import com.sh.node.node;

public interface LinkedListInerface {
	public int getSize();
//	print all elements in List
	public Integer[] getAll();
//	get element at specific position in list
	public Integer getPos(int pos);
//	Print first element
	public Integer getFirst();
//	get last element
	public Integer getLast() ;
//	Add element add start
	public void addAtStart(int data);
//	Add element at last
	public void addAtEnd(int data);
//	Add element at Specific Position
	public void AddAtPos(int data,int pos) ;
	public void deleteFromStart();
	public void deleteFromLast();
	public void deleteFromPosition(int pos);
//	sort the element in list
	public void sort();	
//	search element in the array
	public Integer search(int data);
}
