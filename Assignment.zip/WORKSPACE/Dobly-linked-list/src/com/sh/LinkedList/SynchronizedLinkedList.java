package com.sh.LinkedList;

public class SynchronizedLinkedList implements LinkedListInerface {
	final LinkedList list=new LinkedList();
	
	
	
	public SynchronizedLinkedList(LinkedList list) {
		synchronized(this) {
			if(list==null)
				throw new NullPointerException("Empty List");
			for(int i=1;i<=list.getSize();i++)
			{	
				this.list.addAtEnd(list.getPos(i));
			}
			}	
	}

	@Override
	public int getSize() {
		// TODO Auto-generated method stub
		synchronized(this){return list.getSize();}
	}
	
	@Override
	public Integer getPos(int pos) {
		synchronized (this) {return list.getPos(pos);}	
	}
	
	@Override
	public Integer[] getAll() {
		// TODO Auto-generated method stub
		synchronized (this) {return list.getAll();}
		
	}

	@Override
	public Integer getFirst() {
		// TODO Auto-generated method stub
		synchronized (this) {return list.getFirst();}
	}

	@Override
	public Integer getLast() {
		// TODO Auto-generated method stub
		synchronized (this) {return list.getLast();}
	}

	@Override
	public void addAtStart(int data) {
		// TODO Auto-generated method stub
		synchronized (this) {list.addAtStart(data);}
	}

	@Override
	public void addAtEnd(int data) {
		// TODO Auto-generated method stub
		synchronized (this) {list.addAtEnd(data);}
	}

	@Override
	public void AddAtPos(int data, int pos) {
		// TODO Auto-generated method stub
		synchronized (this) {list.AddAtPos(data, pos);}
	}

	@Override
	public void sort() {
		// TODO Auto-generated method stub
		synchronized (this) {list.sort();}
		
	}

	@Override
	public void deleteFromStart() {
		// TODO Auto-generated method stub
		synchronized (this) {list.deleteFromStart();;}
	}

	@Override
	public void deleteFromLast() {
		// TODO Auto-generated method stub
		synchronized (this) {list.deleteFromLast();;}
	}

	@Override
	public void deleteFromPosition(int pos) {
		// TODO Auto-generated method stub
		synchronized (this) {list.deleteFromPosition(pos);}
		
	}

	@Override
	public Integer search(int data) {
		// TODO Auto-generated method stub
		return 0;
	}

}
