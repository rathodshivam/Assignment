package asa;
import java.util.*;
public class list {
	public static void main(String ar[])
	{
	


	 Map<Integer,String> m=new HashMap<Integer,String>();
	 m.put(101,"sita");
	 m.put(102,"ram");
	 m.put(103,"lucky");

	 Map<Integer,String> m1=new HashMap<Integer,String>();
	 m1.put(1001,"sita");
	 m1.put(102,"ram");
	 m1.put(1003,"lucky");

	 
		List<Map<Integer,String>> l=new ArrayList<Map<Integer,String>>();
		l.add(m);
		l.add(m1);
		System.out.println(l);
}
}

