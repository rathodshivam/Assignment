package com.sh.ListOfMap;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

public class ListOfMap {

	public static void main(String[] args) {
		Map<String, Object> m1=new HashMap<String, Object>();
		m1.put("RollNumber", (Integer)101);
		m1.put("Name", (String)"abc");
		m1.put("Course", (String)"MCA");

		Map<String, Object> m2=new HashMap<String, Object>();
		m2.put("RollNumber", (Integer)102);
		m2.put("Name", (String)"pqr");
		m2.put("Course", (String)"MCA");

		Map<String, Object> m3=new HashMap<String, Object>();
		m3.put("RollNumber", (Integer)103);
		m3.put("Name", (String)"xyz");
		m3.put("Course", (String)"BCA");

		Map<String, Object> m4=new HashMap<String, Object>();
		m4.put("RollNumber", (Integer)104);
		m4.put("Name", (String)"aaa");
		m4.put("Course", (String)"MCA");

		Map<String, Object> m5=new HashMap<String, Object>();
		m5.put("RollNumber", (Integer)105);
		m5.put("Name", (String)"bbb");
		m5.put("Course", (String)"BSC");

		Map<String, Object> m6=new HashMap<String, Object>();
		m6.put("RollNumber", (Integer)106);
		m6.put("Name", (String)"tuv");
		m6.put("Course", (String)"BCA");

		Map<String, Object> m7=new HashMap<String, Object>();
		m7.put("RollNumber", (Integer)107);
		m7.put("Name", (String)"hhh");
		m7.put("Course", (String)"BSC");

		Map<String, Object> m8=new HashMap<String, Object>();
		m8.put("RollNumber", (Integer)108);
		m8.put("Name", (String)"zzz");
		m8.put("Course", (String)"MCA");

		Map<String, Object> m9=new HashMap<String, Object>();
		m9.put("RollNumber", (Integer)109);
		m9.put("Name", (String)"yyy");
		m9.put("Course", (String)"BBA");

		Map<String, Object> m10=new HashMap<String, Object>();
		m10.put("RollNumber", (Integer)110);
		m10.put("Name", (String)"lll");
		m10.put("Course", (String)"BCA");

		Map<String, Object> m11=new HashMap<String, Object>();
		m11.put("RollNumber", (Integer)111);
		m11.put("Name", (String)"uuu");
		m11.put("Course", (String)"BCOM");

		Map<String, Object> m12=new HashMap<String, Object>();
		m12.put("RollNumber", (Integer)112);
		m12.put("Name", (String)"bbb");
		m12.put("Course", (String)"BE");

		List<Map<String,Object>> l1=new ArrayList<Map<String,Object>>();
		l1.add(m1);
		l1.add(m2);
		l1.add(m3);
		l1.add(m4);
		l1.add(m5);
		l1.add(m6);
		l1.add(m7);
		l1.add(m8);
		l1.add(m9);
		l1.add(m10);
		l1.add(m11);
		l1.add(m12);
		
		List<Map<String,Object>> l2=new ArrayList<Map<String,Object>>();
		l1.add(m1);
		l1.add(m3);
		l1.add(m5);
		l1.add(m7);
		l1.add(m9);
		l1.add(m11);
		
		List<Map<String,Object>> l3=new ArrayList<Map<String,Object>>();
		
		l3 = l1.stream().map(x->{
			Optional<Map<String,Object>> opt = l2.stream().filter(y->{
				Set<String> set=y.keySet();
				for(String s:set)
					return x.containsKey(s);
				return false;
				}).findFirst();
			Map<String,Object> map=null;	
			if(opt.isPresent()){
				map= opt.get();	
			}
			return map;
		}).collect(Collectors.toList());
		
		System.out.println(l3);
//		l3.stream().map(x->{
//			System.out.println("as "+x);
//			return x;	
//			}
//		).collect(Collectors.toList());
	}

}



//Student student1 = new Student(101,"abc","MCA");
//Student student2 = new Student(102,"pqr","MCA");
//Student student3 = new Student(103,"xyz","BCA");
//Student student4 = new Student(104,"aaa","BCA");
//Student student5 = new Student(105,"bbb","BCA");
//Student student6 = new Student(106,"tuv","BSC");
//Student student7 = new Student(107,"hhh","BSC");
//Student student8 = new Student(108,"zzz","BBA");
//Student student9 = new Student(109,"yyy","BCOM");
//Student student10 = new Student(1010,"lll","BE");
//Student student11 = new Student(1011,"uuu","BE");
//Student student12 = new Student(1012,"bbb","BCOM");
